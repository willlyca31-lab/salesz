
const cartItems = document.getElementById("cart-items");
const total = document.getElementById("total");
const clearBtn = document.getElementById("clear-cart");

let cart = JSON.parse(localStorage.getItem("cart")) || [];

function displayCart(){

cartItems.innerHTML = "";

let totalPrice = 0;

cart.forEach(item => {

totalPrice += item.price;

cartItems.innerHTML += `
<div class="cart-item">
<h3>${item.name}</h3>
<p>$${item.price}</p>
</div>
`;

});

total.textContent = "Total: $" + totalPrice;

}

displayCart();

clearBtn.addEventListener("click",()=>{

localStorage.removeItem("cart");

cart = [];

displayCart();

});
