
const productsContainer = document.getElementById("products");
const searchInput = document.getElementById("searchInput");

function showProducts(items){

productsContainer.innerHTML = "";

items.forEach(product => {

productsContainer.innerHTML += `
<div class="card">
<img src="${product.image}">
<h3>${product.name}</h3>
<p class="price">$${product.price}</p>
<button class="btn" onclick="addToCart(${product.id})">Agregar</button>
</div>
`;

});

}

showProducts(products);

searchInput.addEventListener("input",(e)=>{

const text = e.target.value.toLowerCase();

const filtered = products.filter(product =>
product.name.toLowerCase().includes(text)
);

showProducts(filtered);

});

function addToCart(id){

const cart = JSON.parse(localStorage.getItem("cart")) || [];

const product = products.find(p => p.id === id);

cart.push(product);

localStorage.setItem("cart", JSON.stringify(cart));

alert("Producto agregado");

}
