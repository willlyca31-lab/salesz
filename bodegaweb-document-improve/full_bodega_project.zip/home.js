
const featured = document.getElementById("featured-products");

products.slice(0,2).forEach(product => {

featured.innerHTML += `
<div class="card">
<img src="${product.image}">
<h3>${product.name}</h3>
<p class="price">$${product.price}</p>
<a href="products.html" class="btn">Comprar</a>
</div>
`;

});
